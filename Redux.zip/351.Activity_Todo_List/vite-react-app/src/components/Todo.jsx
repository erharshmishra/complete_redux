import { useSelector } from "react-redux";
import AddForm from "./AddForm";
import { useDispatch } from "react-redux";
import { deleteTodo } from "../features/todo/todoSlice";

export default function Todo() {
  const todos = useSelector((state) => state.todos);

  const dispatch = useDispatch();
  const clickHandler = (id) => {
    dispatch(deleteTodo(id));
  };

  const marksAsDone = (id) => {
    dispatch(marksAsDone(true));
    console.log(todos);
  };

  return (
    <>
      <h2>Todo List App</h2>
      <AddForm />
      <ul>
        {todos.map((todo) => (
          <li key={todo.id}>
            {todo.task} &nbsp;&nbsp;
            <button onClick={() => clickHandler(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </>
  );
}
